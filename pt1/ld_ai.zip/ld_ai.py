import numpy as np
import pandas as pd
import xlwings as xw
import os
from bokeh.plotting import figure, show
from bokeh.io import output_notebook
from bokeh.models import  ColumnDataSource, HoverTool
from collections import OrderedDict

@xw.sub
def make_load_region():
#	xw_wb = xw.Book.caller()
#	xw_wb = xw.Book(r'C:/ld_ai/ld_ai.xlsm').set_mock_caller()
	xw_wb = xw.Book(r'C:/ld_ai/ld_ai.xlsm')
	ld_wb = xw_wb.sheets['ldrg2014']
	os.chdir(xw_wb.api.path)
#	ld_wb.range("M1").value = "Hello xlwings!"

	file = r'C:/ld_ai/ld_ai.xlsm'
	RES = xw_wb.sheets['Sheet1']
	loadregion_sheet=RES.range("loadregion_sheet").value

	df = pd.read_excel(file,sheetname=loadregion_sheet, parse_cols = 'A:Y')
	df['date'] = df['date'].apply(lambda x: pd.to_datetime(str(x), format='%Y%m%d'))
	
	#df['day-of-week'] = df['date'].weekday()
	df.set_index('date', inplace=True)
	df.iloc[:,0:23] = df.iloc[:,0:23].applymap(np.int64)

	ldrg = pd.read_excel(file,sheetname='ldrg2014', parse_cols = 'A:G')
	ldrg=ldrg.dropna()
	cols=['from','to','start','end','is_peak','is_weekend']
	ldrg[cols] = ldrg[cols].applymap(np.int64)
	ldrg['from'] = ldrg['from'].apply(lambda x: pd.to_datetime(str(x), format='%Y%m%d'))
	ldrg['to'] = ldrg['to'].apply(lambda x: pd.to_datetime(str(x), format='%Y%m%d'))
	ldrg['hours']=0

	for index, row in ldrg.iterrows():
		start_date=row['from']
		end_date=row['to']
		df1 = df.loc[start_date:end_date]
		if (row['is_weekend']):
			df1=df1[df1.index.dayofweek>=5]
		else:
			df1=df1[df1.index.dayofweek<5]
		
		no_of_dates=df1.shape[0]	
		start_time=row['start']
		end_time=row['end']
		if (start_time<end_time):
			load_sum = df1.iloc[:,(start_time-1):end_time].sum().sum()
			load_max = df1.iloc[:,(start_time-1):end_time].max().max()
			no_of_hours=end_time-(start_time-1)
		else:
			load_sum = df1.iloc[:,(start_time-1):].sum().sum()
			load_max1 = df1.iloc[:,(start_time-1):].max().max()
			load_sum += df1.iloc[:,:end_time].sum().sum()
			load_max2 = df1.iloc[:,:end_time].max().max()
			load_max=max(load_max1,load_max2)
			no_of_hours=24-(start_time-1)
			no_of_hours+=end_time
		ldrg.set_value(index,'MWh',load_sum)
		ldrg.set_value(index,'load_max',load_max)
		ldrg.set_value(index,'hours',no_of_dates*no_of_hours)
		ldrg.set_value(index,'load',load_sum/(no_of_dates*no_of_hours))

	peakMWh=df.iloc[:,0:23].max().max()
	total_hours=ldrg['hours'].sum()
	total_MWh=ldrg['MWh'].sum()
	average_MWh=total_MWh/total_hours
	ldrg['average']=ldrg['MWh']/ldrg['hours']
	ldrg['length']=ldrg['hours']/total_hours
	ldrg['factor']=(ldrg['MWh']/ldrg['hours'])/average_MWh
	ldrg['load']=ldrg['factor']*ldrg['length']
	print("total hours="+str(total_hours)+", totalMWh="+str(total_MWh)+", average_MWh="+str(average_MWh))
	print("total length="+str(ldrg['length'].sum())+", total_load="+str(ldrg['load'].sum())+", max_factor="+str(ldrg['factor'].max()))
	ind=ldrg.index[ldrg['factor'] == ldrg['factor'].max()][0]
	print("max facotr index="+str(ind)+", max_factor="+str(ldrg['factor'].max()))
	print("peak MWh="+str(peakMWh)+' peak ratio=' + str(peakMWh/average_MWh) )
	
	ld_cols=['name','from','to','start','end','is_peak','is_weekend','MWh','hours','average','load_max','load','length','factor']
	ldrg = ldrg[ld_cols]
	sht = xw_wb.sheets['Sheet1']
	sht.range('A5').value=ldrg
    
	avg_max_idx=int(ldrg['average'].idxmax())
	load_max_idx=int(ldrg['load_max'].idxmax())
	factor_max_idx=int(ldrg['factor'].idxmax())
	sht.range('A3').value=avg_max_idx   
	col1=ld_cols.index('average')+1
	sht.range('B3').value=col1   
	sht.range('A5').offset(avg_max_idx+1,int(ld_cols.index('average'))+1).color=(255,0,0)
	sht.range('A5').offset(load_max_idx+1,int(ld_cols.index('load_max'))+1).color=(0,255,0)
	sht.range('A5').offset(factor_max_idx+1,int(ld_cols.index('factor'))+1).color=(255,0,0)
	
	cur_row=ldrg.shape[0]+7
	sht.range('A'+str(cur_row)).value="total hours="+str(total_hours)+", totalMWh="+str(total_MWh)+", average_MWh="+str(average_MWh)
	cur_row+=1
	sht.range('A'+str(cur_row)).value="total length="+str(ldrg['length'].sum())+", total_load="+str(ldrg['load'].sum())+", max_factor="+str(ldrg['factor'].max())
	ind=ldrg.index[ldrg['factor'] == ldrg['factor'].max()][0]
	cur_row+=1
	sht.range('A'+str(cur_row)).value="max facotr index="+str(ind)+", max_factor="+str(ldrg['factor'].max())
	cur_row+=1
	sht.range('A'+str(cur_row)).value="peak MWh="+str(peakMWh)+' peak ratio=' + str(peakMWh/average_MWh)
	
	npa = df.as_matrix()   
	rows,cols = np.where(npa == np.amax(npa))
	cur_row+=1
	sht.range('A'+str(cur_row)).value='Peak MWh  : rows='+str(rows[0])+', cols='+str(cols[0])
	cur_row+=1
	date=df.index[rows[0]].strftime('%Y-%m-%d')
	sht.range('A'+str(cur_row)).value='Peak MWh  : rows='+str(date)+', cols='+str(cols[0]+1)+'hour'

	
	#nth largest index
	idx = np.argpartition(npa.ravel(),npa.size-3)[-3:]
	xx=np.column_stack(np.unravel_index(idx, npa.shape))
	
	cur_row+=1
	sht.range('A'+str(cur_row)).value='idx : '+str(rows[0])+', cols='+str(cols[0])
	return df
		
	#mask = (df['from'] >= start_date) & (df['to'] <= end_date)
	#df.loc[df['a'] == 1, 'b'].sum()

def draw_bokeh(df):
	df2=df
	#df2['date'] = df2['date'].dt.date
	#df2.set_index('date', inplace=True)
	df2=df2.stack()  # produce Series
	df2=pd.DataFrame({'date':df2.index,'MWh':df2.values})  # convert Series to DataFrame
	df2['day'], df2['hour']=zip(*df2.date)
	df2['day'] = df2['day'].dt.date
	df2 = df2.drop('date',axis=1)
	df2['hour']=pd.to_numeric(df2['hour'].map(lambda x: str(x)[:-1]))
	df2['TDate'] = pd.to_datetime(df2.day)
	df2['TDate'] += pd.to_timedelta(df2.hour, unit='h')
    
	header = ["TDate", "MWh"]
	df2.to_csv('ld2014.csv', columns = header, encoding='utf-8', index=False)

	source = ColumnDataSource(
        data=dict(
            x=df2.TDate,
            y=df2.MWh,
            desc=df2.hour,
        )
    )
	#x=df2.day
	#y=df2.MWh
	#desc=df2.hour
	pl = figure(title='2014 MWh',x_axis_type='datetime',width=1800, height=600)
	pl.line(x='x', y='y',source=source, legend="MWh")
	hover = HoverTool(
		tooltips=[
			('Date', '@x{%F}'),
			('MWh', '@y{int}'),
			('hour', '@desc')
		],
		formatters={'x': 'datetime'},
		mode='vline'
	)
	pl.add_tools(hover)
	show(pl) 

@xw.func
def hello(name):
    return "hello {0}".format(name)

	
def my_macro():
	xw_wb = xw.Book.caller()
	ld_wb = xw_wb.sheets['foregen_year_2014']
	os.chdir(xw_wb.api.path)

if __name__=="__main__":
#	xw_wb = xw.Book(r'C:/elecGAMS/elec_GAMS_excel/elec_GAMS_excel.xlsm').set_mock_caller()
	df=make_load_region()
	draw_bokeh(df)
