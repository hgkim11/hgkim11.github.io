'''
Python 3.6
xlwings 0.11
GAMS 24.8.5
'''
import xlwings as xw
from gams import *
import os, shutil
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#from win32com.client import Dispatch

@xw.sub
def get_optimal_GAMS_python_xlwings():
	xw_wb = xw.Book.caller()
	RES = xw_wb.sheets['RES']
	sht = xw_wb.sheets['pyGAMSsolution']		
	'''
	xw_wb = xw.Book(r'C:/excelBufEEEpy/excelBufEEEpy.xlsm')
	RES = xw_wb.sheets['RES']
	sht = xw_wb.sheets['Solution']	
	'''
	os.chdir(xw_wb.api.path)
	sht.range('A1').value	= 'cwd=' + os.getcwd()
	print('cwd=' + os.getcwd())
	
	ws = GamsWorkspace(os.getcwd())
	#cp = ws.add_checkpoint()
	
	lp_file="tr_khg_vi.lp"
	file1 = open(os.path.join(ws.working_directory, "cplex.opt"), "w")	
	file1.write("writelp %s" % lp_file)
	file1.close()
	
	t2 = ws.add_job_from_file(os.path.join(os.getcwd(),"tr_model_vi.gms"))
	#t2 = ws.add_job_from_string("ms=transport.modelstat; ss=transport.solvestat;", cp)
	opt = ws.add_options()
	opt.optfile=1
	opt.defines["incname"] = "tr_data_vi"
	t2.run(gams_options=opt)
	
	sht.clear_contents()	
	sht.range('A2').value	= "GAMS Obj: {:,.2f}".format(t2.out_db["z"].find_record().level)
	# https://www.gams.com/latest/docs/apis/python/classgams_1_1workspace_1_1_model_stat.html
	# In the file "tr_model_vi.gms", append "Scalar modelstat / /;	modelstat=tr.modelstat;"
	#Solve tr using lp minimizing z ;
	#Scalar modelstat / /;
	#modelstat=tr.modelstat;
	if (int(t2.out_db["modelstat"].find_record().value)==1):
		modelstat="Optimal"
	elif (int(t2.out_db["modelstat"].find_record().value)==4):
		modelstat="Infeasible"
	else:
		modelstat="modelstat error"
	sht.range('B2').value="  Modelstatus: " + modelstat

	#from win32com.client import Dispatch
	#app_xl = Dispatch("Excel.Application")
	#wb = app_xl.ActiveWorkbook
	#wb.Sheets("Sheet4").Cells.ClearContents()
	#start_year=int(wb.Sheets('RES').Range("start_year").Value)
	
	start_year=int(RES.range("start_year").value)
	end_year=int(RES.range("end_year").value)
	tau=int(RES.range("tau").value)
	T=list(range(1,tau+1))
	YEAR=list(range(start_year,end_year+1))
	sht.range('B3').value=YEAR
	sht.range('B4').value=T
	tech_names=[rec.text for rec in t2.out_db["I"]]
	eform_names=[rec.text for rec in t2.out_db["J"]]
	I=[int(rec.key(0))-1 for rec in t2.out_db["I"]]
	I_0=[int(rec.key(0))-1 for rec in t2.out_db["I_0"]]
	J=[int(rec.key(0))-1 for rec in t2.out_db["J"]]
	K_J=[int(rec.key(0))-1 for rec in t2.out_db["K"]]
	noOfTechs=len(tech_names)
	noOfeForms=len(eform_names)

	demand=np.zeros((noOfeForms,tau))
	x=np.zeros((noOfTechs,tau))
	X_out=np.zeros((noOfTechs,tau))
	y=np.zeros((noOfTechs,tau))
	H=np.zeros((noOfTechs,tau))
	Y_cap=np.zeros((noOfTechs,tau))
	for rec in t2.out_db["dem"]:   # 2D parameter 
		demand[int(rec.key(0))-1,int(rec.key(1))-1]=rec.value
	for rec in t2.out_db["x"]:      # 2D variable
		x[int(rec.key(0))-1,int(rec.key(1))-1]=rec.level
	for rec in t2.out_db["X_out"]:
		X_out[int(rec.key(0))-1,int(rec.key(1))-1]=rec.level
	for rec in t2.out_db["y"]:
		y[int(rec.key(0))-1,int(rec.key(1))-1]=rec.level
	for rec in t2.out_db["H"]:
		H[int(rec.key(0))-1,int(rec.key(1))-1]=rec.value
	for rec in t2.out_db["Y_cap"]:
		Y_cap[int(rec.key(0))-1,int(rec.key(1))-1]=rec.level

	row=5	
	demand_names=[['dem['+eform+'('+str(index+1)+')]'] for index, eform in enumerate(eform_names)
				if (index in K_J)]
	sht.range('A'+str(row)).value=demand_names
	sht.range('B'+str(row)).value=np.delete(demand, np.setdiff1d(J, K_J), axis=0) 
	row+=len(demand_names)+1
		
	x_names=[['x['+tech+'('+str(index+1)+')]'] for index, tech in enumerate(tech_names)]	
	sht.range('A'+str(row)).value=x_names	
	sht.range('B'+str(row)).value = x
	row+=len(x_names)+1
	
	X_out_names=[['X_out['+tech+'('+str(index+1)+')]'] for index, tech in enumerate(tech_names)]
	sht.range('A'+str(row)).value=X_out_names	
	sht.range('B'+str(row)).value = X_out
	X_out_sum=X_out.sum(axis=0)
	sht.range('A'+str(row+len(X_out_names))).value = 'X_out_sum'
	sht.range('B'+str(row+len(X_out_names))).value = X_out_sum
	row+=len(X_out_names)+2
	
	Y_cap_names=[['Y_cap['+tech+'('+str(index+1)+')]'] for index, tech in enumerate(tech_names)
						if (index not in I_0)]
	sht.range('A'+str(row)).value=Y_cap_names	
	sht.range('B'+str(row)).value = np.delete(Y_cap, I_0, axis=0)
	#sht.range('S'+str(row)).value = np.vstack(peak_contrib)
	Y_cap_sum=Y_cap.sum(axis=0)
	sht.range('A'+str(row+len(Y_cap_names))).value = 'Y_cap_sum'
	sht.range('B'+str(row+len(Y_cap_names))).value = Y_cap_sum	
	row+=len(Y_cap_names)+2		
	
	y_names=[['y['+tech+'('+str(index+1)+')]'] for index, tech in enumerate(tech_names)
				if (index not in I_0) ]
	sht.range('A'+str(row)).value=y_names	
	sht.range('B'+str(row)).value =  np.delete(y, I_0, axis=0)
	y_sum=y.sum(axis=0)
	sht.range('A'+str(row+len(y_names))).value = 'y_sum'
	sht.range('B'+str(row+len(y_names))).value = y_sum
	row+=len(y_names)+2		
	
	H_names=[['H['+tech+'('+str(index+1)+')]'] for index, tech in enumerate(tech_names)
				if (index not in I_0)]
	sht.range('A'+str(row)).value=H_names	
	sht.range('B'+str(row)).value =  np.delete(H, I_0, axis=0)
	H_sum=H.sum(axis=0)
	sht.range('A'+str(row+len(H_names))).value = 'H_sum'
	sht.range('B'+str(row+len(H_names))).value = H_sum
	
if __name__=="__main__":
	xw_wb = xw.Book(r'C:/excelBufEEEpy/excelBufEEEpy.xlsm').set_mock_caller()
	get_optimal_GAMS_python_xlwings()
